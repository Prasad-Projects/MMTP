'''
Created on 19-Aug-2013

@author: Kashaj
'''
import sqlite3
db = sqlite3.connect('Train_info.db')
db.text_factory = str
db.row_factory = sqlite3.Row
db.execute('drop table if exists StationInfo')
db.execute('create table StationInfo(Station_Name char[20],Station_Code text)')

def main():
    f = open('stationlistfinal.txt','r')
    #outbytes = bytearray()
    for lines in f:
        #for c in lines:
            #if ord(c) > 127:
                #outbytes += bytes('&#{:04d};'.format(ord(c)),encoding= 'utf_8')
            #else: outbytes.append(ord(c))
                
        #lines = str(outbytes,encoding='utf_8')
        lines = lines.strip('\n')
        lines = lines.strip(' ')
        lines=lines.split(',')
        print(lines[0].replace('\xa0',' '),lines[1])
        lines = (lines[0].replace('\xa0',' ').replace('.',''),lines[1])
        dataput(lines)
    
    getData()    
    db.commit() 
    print 'OK DONE'   
    
     
def dataput(traininfolines):
    db.execute('insert into StationInfo(Station_Name,Station_Code) values (?, ?)',(str(traininfolines[0]),str(traininfolines[1])))       

def getData():
    cursor = db.execute('Select Station_Name, Station_Code from StationInfo')
    count = 0;
    for row in cursor:
        print(row['Station_Name'],row['station_code'])
        count -= 1
    print count    
if __name__ == '__main__' :
    main()        