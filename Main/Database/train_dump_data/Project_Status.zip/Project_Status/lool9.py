'''
Created on 24-Aug-2013

@author: Kashaj
'''
import httplib, urllib, re, sqlite3
db = sqlite3.connect('train_Schedule.db')
db.text_factory = str
db.row_factory = sqlite3.Row
db.execute('drop table if exists TrainschdInfo')
db.execute('drop table if exists TrainDaysInfo')
db.execute('create table TrainschdInfo(Train_Num int,stn_code char[6],route int,arr_time text,dep_time text)')

def main():
    tr_num = open('numlist.txt','r')
    count=0
    for num in tr_num:
        num = str(num)
        num = num.strip(' ')
        num = num.strip('\n')
        #num = 18047;
        hwrite(num)
        hread()
        tuples = hwork()
        hdatab(num,tuples)
        count += 1;
        if(count == 0):break
        
        
        
    print(count)
    #getData()
    db.commit() 
    print 'OK DONE'   
def hwrite(num):
     
    params = urllib.urlencode({'lccp_trnname': num, 'getIt': 'Please+Wait...'})
    headers = {"Host": "www.indianrail.gov.in", "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:22.0) Gecko/20100101 Firefox/22.0", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language": "en-US,en;q=0.5", "Referer": "http://www.indianrail.gov.in/train_Schedule.html", "Connection": "keep-alive", "Content-Type": "application/x-www-form-urlencoded", "Content-Length": "39"}
    conn = httplib.HTTPConnection("www.indianrail.gov.in:80")
    conn.request("POST", "/cgi_bin/inet_trnnum_cgi.cgi", params, headers)
    response = conn.getresponse()
    print response.status, response.reason
    data = response.read()

    fileh = open('output10.html' ,'w')
    fileh.write(data)
    fileh.close()
    #print data
    conn.close() 

def hread():
    f = open('output10.html','rU')
    text = f.read()
    text = text.strip('\n')
    print type(text)
    f2 = open('loolws.txt','w')
    f2.write(text)
    #print text
    f2.close() 
    
def hwork():    
    f = open('loolws.txt','r')
    text = f.read()
    tuples = re.findall(r'<TR>\n<TD>\d+</TD>\n<TD>(\w+\s*)</TD>\n<TD>\w+.*</TD>\n<TD>(\d)+</TD>\n<TD>(.+)</TD>\n<TD>(.+)</TD>\n<TD>.*</TD>\n<TD>\d+</TD>\n<TD>\d+</TD>',text,re.IGNORECASE)
    print(len(tuples))
    #print tuples
    return(tuples)
    f.close() 
             
def hdatab(num,tuples):
    for i in range(0,len(tuples)):
        if(i==0):
            db.execute('insert into TrainschdInfo(Train_Num,stn_code,route,arr_time,dep_time) values (?,?,?,?,?)',(num,tuples[i][0],tuples[i][1],(tuples[i][2]).replace('<FONT COLOR = red>', ''),(tuples[i][3])))
        elif(i == (len(tuples)-1)):
            db.execute('insert into TrainschdInfo(Train_Num,stn_code,route,arr_time,dep_time) values (?,?,?,?,?)',(num,tuples[i][0],tuples[i][1],tuples[i][2],(tuples[i][3]).replace('<FONT COLOR = red>', '')))
        
        else:
            db.execute('insert into TrainschdInfo(Train_Num,stn_code,route,arr_time,dep_time) values (?,?,?,?,?)',(num,tuples[i][0],tuples[i][1],tuples[i][2],(tuples[i][3]).replace('<FONT COLOR = red>', '')))
               

def getData():
    cursor = db.execute('Select Train_Num,stn_code,route,arr_time,dep_time from TrainschdInfo')
    count = 0;
    for row in cursor:
        print(row['Train_Num'],row['stn_code'],row['route'],row['arr_time'],row['dep_time'])
        count -= 1
    print count           
if __name__ == '__main__':
    main()    