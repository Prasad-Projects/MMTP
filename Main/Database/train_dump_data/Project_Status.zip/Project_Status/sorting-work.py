'''
Created on 10-Sep-2013

@author: Kashaj
'''
def main():
    f = open('algo1.txt','r')
    list = []
    text = ''
   
    for lines in f:
        tuples = lines.split(',')
        list.append(tuples)
        
    list = sorted(list)
    for things in list:
        things = ','.join(things)
        text += things
 
    f1 = open('sortedAlgo1.txt','w')
    f1.write(text);
    f.close;
    f1.close;
    
    
    
if __name__ == '__main__':
    main()    