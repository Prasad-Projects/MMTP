'''
Created on 19-Aug-2013

@author: Kashaj
'''
import sqlite3
db = sqlite3.connect('Train_info.db')
db.row_factory = sqlite3.Row
db.execute('drop table if exists TrainInfo')
db.execute('create table TrainInfo(train_num int,train_name text,src text,dest text)')
def main():
    f = open('trainnumlist.txt','r')
    for lines in f:
        lines = str(lines);
        lines=lines.split(',')
        dataput(lines)
    
    getData()    
    db.commit() 
    
    print 'OK DONE'    
def dataput(traininfolines):
    db.execute('insert into TrainInfo(train_num, train_name, src, dest) values (?, ?, ?, ?)',(traininfolines[0],traininfolines[1],traininfolines[2],traininfolines[3]))       

def getData():
    cursor = db.execute('Select train_num, train_name from TrainInfo')
    count = 0;
    for row in cursor:
        print(row['train_num'],row['train_name'])
        count -= 1
    print count    
if __name__ == '__main__' :
    main()        