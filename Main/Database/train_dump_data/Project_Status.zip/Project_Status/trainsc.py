'''
Created on 23-Aug-2013

@author: Kashaj
'''
import httplib, urllib, re, sqlite3
db = sqlite3.connect('trainRunDays.db')
db.text_factory = str
db.row_factory = sqlite3.Row
#db.execute('drop table if exists TrainDaysInfo')
#db.execute('create table TrainDaysInfo(Train_Num char[5],Week_Days char[30])')

def main():
    tr_num = open('numlistc.txt','r')
    count=0
    for num in tr_num:
        
        num = str(num)
        
        print(num)
        num = num.strip(' ')
        num = num.strip('\n')
        #num = 18047;
        hwrite(num)
        hread()
        Days = hwork()
        hdatab(num,Days)
        count += 1
        
    
    getData()
    db.commit() 
    print(count)
    print 'OK DONE'   
def hwrite(num):
     
    params = urllib.urlencode({'lccp_trnname': num, 'getIt': 'Please+Wait...'})
    headers = {"Host": "www.indianrail.gov.in", "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:22.0) Gecko/20100101 Firefox/22.0", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language": "en-US,en;q=0.5", "Referer": "http://www.indianrail.gov.in/train_Schedule.html", "Connection": "keep-alive", "Content-Type": "application/x-www-form-urlencoded", "Content-Length": "39"}
    conn = httplib.HTTPConnection("www.indianrail.gov.in:80")
    conn.request("POST", "/cgi_bin/inet_trnnum_cgi.cgi", params, headers)
    response = conn.getresponse()
    print response.status, response.reason
    data = response.read()

    fileh = open('output9.html' ,'w')
    fileh.write(data)
    fileh.close()
    #print data
    conn.close() 

def hread():
    f = open('output9.html','rU')
    text = f.read()
    text = text.strip('\n')
    #print type(text)
    f2 = open('loolwt.txt','w')
    f2.write(text)
    #print text
    f2.close() 
    
def hwork():    
    f = open('loolwt.txt','r')
    text = f.read()
    Days = ''
    tuples = re.findall(r'<TD>(\w\w\w\s)</TD>\n<TD>(\w\w\w\s)</TD>',text)
    print(len(tuples))
    for item in tuples:
        for items in item:
            Days += items
    Days = Days.strip(' ')
              
    tuples1 = re.findall(r'<TD>(\w\w\w)\s</TD></TR>\n</TABLE>',text)
    if(len(tuples1)): match = re.search(tuples1[0],Days)
    else: 
        print Days
        return Days
    
    if match: tuples
    else: 
        Days += (' ' +tuples1[0])  
        print(len(Days))  
    #print Days
    return(Days)
    f.close() 
             
def hdatab(num,Days):
    db.execute('insert into TrainDaysInfo(Train_Num,Week_Days) values (?,?)',(num,Days))
    

def getData():
    cursor = db.execute('Select Train_Num, Week_Days from TrainDaysInfo')
    f = open("TrainsDays.txt",'a')
    count = 0;
    for row in cursor:
        text = str(row['Train_Num'])
        text += ','
        text += str(row['Week_Days'])
        text += '\n'
        f.write(text)
        count -= 1
    print count 
    f.close()
              
if __name__ == '__main__':
    main()    
        